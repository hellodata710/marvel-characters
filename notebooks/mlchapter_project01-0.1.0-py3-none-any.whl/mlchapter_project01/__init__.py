"""mlchapter project01 package for analyzing and predicting character survival."""
